﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class MyDoubleCircle : ShapesWithRadius
    {
        public MyDoubleCircle() { }
        public MyDoubleCircle(double radius) : base(radius) { }
        public override double Area() => PI * Radius * Radius;
        public override double Circumference() => 2 * PI * Radius;
    }
}

/*

public void setRadius(double r)
{
    radius = r;
}
public double Radius { get; set; }

public double areaOfCircle()
{
    try
    {
        area = checked(PI * Math.Pow(radius, 2));
    }
    catch (OverflowException)
    {
        Console.WriteLine("The resulting Area exceeded the MAXIMUM double type value");
    }
    return area;
}
public double circumferenceOfCircle()
{
    try { circumference = checked(2 * PI * radius); }
    catch (OverflowException)
    {
        Console.WriteLine("The resulting Circimference exceeded the MAXIMUM double type value");
    }
    return circumference;
}
public double volumeOfHemisphere()
{
    try
    {
        volume = checked(((4.0 / 3.0) * (PI * Math.Pow(radius, 3))) / 2.0);
    }
    catch (OverflowException)
    {
        Console.WriteLine("The resulting Volume exceeded the MAXIMUM double type value");
    }
    return volume;
} */

